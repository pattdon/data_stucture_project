/* HW9
 * Due: 30 November 2019
 * Problem Header Hash Code: dc540e1a78521988a2e71b5dc65d7825
*/ 
package hw9;

import org.w3c.dom.ls.LSInput;

public class Graph {
    
    Vertex[] vertexList; // This list contain vertices
    List[] adjacencyList; // Graph implemented by Adjacency List
    
    int cap;
    int size;
    int cc;

    public static final int INFINITY = -1;
    public Graph(int cap){
        this.cap = cap;
        size = 0;
        vertexList = new Vertex[cap]; // Create a vertex list (array of vertices)
        adjacencyList = new List[cap]; // Create an adjacency list (array of lists)
    }
    
    public void addVertex(int key){
        if (size==cap) {
            System.out.println("Vertex list is full. You need to recreate the Graph");
            return;
        }
        else {
            // Add an vertex with the key to the list
            // Beware that Graph has 2 constructors
            //
            vertexList[key] = new Vertex(key);
            // Create an empty list to the appropriate location in the adjacency list
            //
            adjacencyList[key] = new List(); // new List to be empty list
            // Increase the vertex counter by one
            //
            size++;
        }
    }
    
    // Two way edge
    // If you make a path from u to v, you must make a path from v to u
    public void addEdge(int u, int v){
        if (vertexList[u]==null){
            System.out.println("Source node does not exist");
            return;
        } if (vertexList[v]==null){
            System.out.println("Destination node does not exist");
            return;
        }
        if (!isConnected(u, v)){// Check if there is already a path from u to v
            // Call a function to connect the source vertex (u) to the destination vertex (v)
            // Hint: Pushback a new Node(v) to the appropriate List(u)
            adjacencyList[u].pushBack(new Node(v));
            // Call a function to connect the destination vertex (v) to the source vertex (u)
            // Hint: Like above but swicth u and v
            adjacencyList[v].pushBack(new Node(u));
        }else{
            System.out.println("There are already a path connecting "+u+" and "+v);
        }
    }
    
    // Check if vertex u is connected with vertex v
    // By checking if the adjacency list u contains a node with key (vertexIndex) equals to v
    public boolean isConnected(int u, int v){
        List list = adjacencyList[u];
        if(list.head!=null) {
            Node node = list.head;
            //check if u is connected to v or not.
            if(node.vertexIndex==v) return true;
            // Do something here
            //
            // while for check all the adjacencyList of u (from node=list of adjacency of u), whether if u is connected to v or not.
            while (node.next != null) {
                if (node.vertexIndex == v){
                    return true;
                }
                node = node.next;
            }
            return false; // Fix this
        }
        return false;
    }

    public void showList(int u){
        Vertex v = vertexList[u];
        List list = adjacencyList[u];
        if (list==null)
            return;
        Node node = list.head;
        System.out.print("Vertex " + v.strKey + " connected to the following vertices: ");
        while(node!=null){
            System.out.print(vertexList[node.vertexIndex].strKey + ", ");
            node = node.next;
        }
        System.out.println();
    }  
    
    public void DFS(){
        // Reset all vertex visited parameters
        for(int i=0;i<size;i++){
            if(vertexList[i]!=null)
            vertexList[i].visited=false;
        }
        // Set cc to 1
        cc=1;
        // Explore unvisited vertices
        // Increase cc by one after each connected component
        //
        for(int i=0;i<size;i++){
            // if that vertex is not visited yet, then explore it recursively.
            if(!vertexList[i].visited){
                Explore(vertexList[i]);
                cc++;
            }
        }
        // Add a new line after finishing all vertices
        System.out.println();
    }
    
    public void Explore(Vertex v){
        
        // Set the current vertex to be visited
        v.visited=true;
        // Stamp cc to the current vertex
        v.ccNum=cc;
        // Print out vertex
        System.out.print(v.strKey +"/"+v.ccNum+" -> ");
        // Recursively explore every node for a particular list
        int index = v.intKey;
        List list = adjacencyList[index];
        Node node = list.head;
        // do something here
        //
        //
        // if vertex is not visited yet explore it recursively to make it visited.
        if(!vertexList[node.vertexIndex].visited){
            Explore(vertexList[node.vertexIndex]);
        }
        while(node.next!=null){
            node=node.next;
            if(!vertexList[node.vertexIndex].visited){
                Explore(vertexList[node.vertexIndex]);
            }
        }
    }
}
