/* HW9
 * Due: 30 November 2019
 * Problem Header Hash Code: dc540e1a78521988a2e71b5dc65d7825
*/
package hw9;

public class HashGraph extends Graph{

    long p; // Big Prime (for PolyHash())
    long x; // Small number (for PolyHash())
    
    public HashGraph(int cap, long p, long x){
        super(cap);
        this.p = p;
        this.x = x;
    }
    
    public void addVertex(String key){
        if (size==cap){
            System.out.println("Vertex list is full. You need to rehash");
            return;
        }
        // The input key will be hashed to an integer using hashCode (with PolyHash) function
        // the index number will be used to identify location of the vertex in the list
        int index = hashCode(key);
        // Add an vertex with the key to the list
	// Beware that Graph has 2 constructors
        //
        vertexList[index] = new Vertex(key);
        // Create an empty list to the appropriate location in the adjacency list
        //
        adjacencyList[index]= new List();
        // Increase the vertex counter by one
        //
        size++;
    }
    
    public void addEdge(String source, String destination){
        int sourceIndex = hashCode(source);
        int destinationIndex = hashCode(destination);
        super.addEdge(sourceIndex, destinationIndex);
    }

    public void BFS(Vertex s){
        
        // Set dist variable of all vertices to infinity
        // Set prev variable of all vertices to nil
        for(int i=0;i<cap;i++){
            if(vertexList[i]!=null){
                vertexList[i].dist = INFINITY;
                vertexList[i].prev = null;
            }
        }
        // Set distance of the source vertex (s) to zero
        s.dist = 0; // Please uncomment this line
        // Push vertex s to a queue
        Queue q = new Queue(cap);
        q.enqueue(s);
        // Perform BFS using Queue
        // Pseudocode is in the slide
        while(!q.isEmpty()){
            Vertex u = q.dequeue();
            int index = hashCode(u.strKey);
            // get an index of u to use it in adjacencyList.
            List list = adjacencyList[index];
            Node node = list.head;
            // perform process following the PseudoCode from slide.
            for(Node v=node;v!=null;v=v.next){
                if (vertexList[v.vertexIndex].dist==INFINITY){
                    q.enqueue(vertexList[v.vertexIndex]);
                    vertexList[v.vertexIndex].dist=u.dist+1;
                    vertexList[v.vertexIndex].prev=u;
                }
            }
        }
    }

    public Stack getShortestPathList(Vertex S, Vertex U){
        Stack stack = new Stack(cap);
        while(U != S){
            stack.push(U);
            U = U.prev;
        }
        stack.push(S);
        return stack;
    }
    
    public void printShortestPath(String s_str, String u_str){
        // Hash the input strings and use them to index the appropriate vertices
        // hash an input string to get an index in the list.
        int s_index = hashCode(s_str); // Fix this, index 0 is wrong
        int u_index = hashCode(u_str); // Fix this, index 0 is wrong
        
        // Perform BFS starting from the source vertex
        BFS(vertexList[s_index]); // Fix this, index 0 is wrong
        
        // Call a function to reconstruct the shortest path list (stack)
        // Hint: the function is somewhere in this Class
        Stack stack = getShortestPathList(vertexList[s_index],vertexList[u_index]); // Fix this, replace new Stack(cap) with calling a function with appropriate parameters
        // Given the correct list (stack) the following code should work
        // The following code is good to go
	// Hint: Do not use u.intKey here because it is undefined, instead please use hashCode(u.strKey)
        while(!stack.isEmpty()){
            System.out.print(stack.pop().strKey+ " -> ");
        }
        System.out.println();
    }
    
    public int hashCode(String s){
        int index = (int)(HashGraph.polyHash(s,p,x) % cap);
        // check if there is a collision at this index
        // if no, just return index

        if(vertexList[index]!=null){
            // check if the key has any collision or not.
            if(!vertexList[index].strKey.equals(s)) {
                for (int k = 1; k<cap-1; k++) {
                    // if same key is found or empty index, break.
                    if (vertexList[index]==null||vertexList[index].strKey.equals(s)) break;
                    index = (index + k * k) % cap;
                }
            }
        }
        // if yes, use the quadratic probing to find an appropriate location
        // Hint: Use for loop starting from k=1 to k = cap-1
        return index;
    }

    public static long polyHash(String s, long p, long x){
        long hash = 0;
        // Implement the poly hashing function here
        for(int i=s.length()-1;i>=0;i--){
            hash=(hash*x+(int)s.charAt(i))%p;
        }
        return hash;
    }
}

